#ifndef __BUZZER_H__
#define __BUZZER_H__

void _buzzerInit();
void stopBuzzer();

#endif
