#ifndef __PIR_H__
#define __PIR_H__

void initPir();
bool PIR_detect();

#endif
